<?php

include('includes/config.php');
include('includes/database.php');
include('includes/functions.php');
  secure();

include('includes/header.php');

if (isset($_POST['username'])){
    $username = $_POST['username'];
    $email = $_POST['email'];
    $hashed = SHA1($_POST['password']);
    $active = $_POST['active'];
    $admin = $_POST['role'];

    if ($stm = $pdo->prepare('INSERT INTO users (username,email, password, active, role) VALUES (?, ?, ?, ?, ?)')){
       
        // $stm->bind_param('ssss', $_POST['username'], $_POST['email'], $hashed,  $_POST['active']);
        $stm->bindValue(1, $username, PDO::PARAM_INT);
        $stm->bindValue(2, $email, PDO::PARAM_INT);
        $stm->bindValue(3, $hashed, PDO::PARAM_INT);
        $stm->bindValue(4, $active, PDO::PARAM_INT);
        $stm->bindValue(5, $admin, PDO::PARAM_STR);
        
        $stm->execute();
        

        set_message("A new user " . $_SESSION['username'] . " has beed added");
        header('Location: users.php');
        $stm->close();
        die();

    } else {
        echo 'Could not prepare statement!';
    }


}


?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
        <h1 class="display-1">Add user</h1>
       
        <form method="post">
                <!-- Username input -->
                <div class="form-outline mb-4">
                    <input type="text" id="username" name="username" class="form-control" />
                    <label class="form-label" for="username">Username</label>
                </div>
                <!-- Email input -->
                <div class="form-outline mb-4">
                    <input type="email" id="email" name="email" class="form-control" />
                    <label class="form-label" for="email">Email address</label>
                </div>

                <!-- Password input -->
                <div class="form-outline mb-4">
                    <input type="password" id="password"  name="password" class="form-control" />
                    <label class="form-label" for="password">Password</label>
                </div>

                <!-- Active select -->
                <div class="form-outline mb-4">
                    <select name="active" class="form-select" id="active" >
                        <option value="1">Active</option>
                        <option value="0">Inactive</option>
                    </select>
                </div>

                <!-- Admin select -->
                <div class="form-outline mb-4">
                    <select name="role" class="form-select" id="admin" >
                        <option value="admin">Admin</option>
                        <option value="user">User</option>
                    </select>
                </div>

                <!-- Submit button -->
                <button type="submit" class="btn btn-primary btn-block">Add user</button>
            </form>


       
        </div>

    </div>
</div>


<?php


include('includes/footer.php');
?>