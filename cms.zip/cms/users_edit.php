<?php

include('includes/config.php');
include('includes/database.php');
include('includes/functions.php');
secure();

include('includes/header.php');

if (isset($_POST['username'])) {

    $username = $_POST['username'];
    $email = $_POST['email'];
    // $hashed = SHA1($_POST['password']);
    $active = $_POST['active'];
    $id = $_GET['id'];
    $admin = $_POST['role'];

    if ($stm = $pdo->prepare('UPDATE users set  username = ?,email = ? , active = ? ,role = ? WHERE id = ?')) {
        // $stm->bind_param('sssi', $_POST['username'], $_POST['email'], $_POST['active'], $_GET['id']);
        $stm->bindValue(1, $username, PDO::PARAM_INT);
        $stm->bindValue(2, $email, PDO::PARAM_INT);
        $stm->bindValue(3, $active, PDO::PARAM_INT);
        $stm->bindValue(4, $admin, PDO::PARAM_STR);
        $stm->bindValue(5, $id, PDO::PARAM_INT);
        

        $stm->execute();




        $stm->closeCursor();

        if (isset($_POST['password'])) {
            if ($stm = $pdo->prepare('UPDATE users set  password = ? WHERE id = ?')) {
                $hashed = SHA1($_POST['password']);
                // $stm->bind_param('si', $hashed, $_GET['id']);
                $stm->bindValue(1, $hashed, PDO::PARAM_INT);
                $stm->bindValue(2, $id, PDO::PARAM_INT);
                $stm->execute();

                $stm->closeCursor();

            } else {
                echo 'Could not prepare password update statement!';
            }
        }

        set_message("A user with id: " . $_GET['id'] . " has been updated");
        header('Location: users.php');
        die();

    } else {
        echo 'Could not prepare user update statement statement!';
    }





}


if (isset($_GET['id'])) {
    $deleteId = $_GET['id'];

    if ($stm = $pdo->prepare('SELECT * from users WHERE id = ?')) {
        // $stm->bind_param('i', $_GET['id']);
        $stm->bindValue(1, $deleteId, PDO::PARAM_INT);
        $stm->execute();

        // $result = $stm->get_result();
        // $user = $result->fetch_assoc();
        $user = $stm->fetch(PDO::FETCH_ASSOC);

        if ($user) {


            ?>
            <div class="container mt-5">
                <div class="row justify-content-center">
                    <div class="col-md-6">
                        <h1 class="display-1">Edit user</h1>

                        <form method="post">
                            <!-- Username input -->
                            <div class="form-outline mb-4">
                                <input type="text" id="username" name="username" class="form-control active"
                                    value="<?php echo $user['username'] ?>" />
                                <label class="form-label" for="username">Username</label>
                            </div>
                            <!-- Email input -->
                            <div class="form-outline mb-4">
                                <input type="email" id="email" name="email" class="form-control active"
                                    value="<?php echo $user['email'] ?>" />
                                <label class="form-label" for="email">Email address</label>
                            </div>

                            <!-- Password input -->
                            <div class="form-outline mb-4">
                                <input type="password" id="password" name="password" class="form-control" />
                                <label class="form-label" for="password">Password</label>
                            </div>

                            <!-- Active select -->
                            <div class="form-outline mb-4">
                                <select name="active" class="form-select" id="active">
                                    <option <?php echo ($user['active']) ? "selected" : ""; ?> value="1">Active</option>
                                    <option <?php echo ($user['active']) ? "" : "selected"; ?> value="0">Inactive</option>
                                </select>
                            </div>

                            <div class="form-outline mb-4">
                    <select name="role" class="form-select" id="admin" >
                        <option value="admin">Admin</option>
                        <option value="user">User</option>
                    </select>
                </div>

                            <!-- Submit button -->
                            <button type="submit" class="btn btn-primary btn-block">Update user</button>
                        </form>



                    </div>

                </div>
            </div>


            <?php
        }
        $stm->closeCursor();
     

    } else {
        echo 'Could not prepare statement!';
    }

} else {
    echo "No user selected";
    die();
}

include('includes/footer.php');
?>